﻿using System;
using System.Collections.Generic;
using System.IO;
using SQLite;
using UTeach.Tables;
using Xamarin.Forms;

namespace UTeach.Views
{
    public partial class TeacherStudent : ContentPage
    {
        public TeacherStudent()
        {
            InitializeComponent();
        }

        async void Handle_Clicked_3(object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new StudentStrengths());

        }
    }
}
