﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace UTeach.Views
{
    public partial class StudentWeakness : ContentPage
    {
        public StudentWeakness()
        {
            InitializeComponent();
        }
    }
}
