﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace UTeach.Views
{
    public partial class TeacherGrade : ContentPage
    {
        public TeacherGrade()
        {
            InitializeComponent();
        }
    }
}
