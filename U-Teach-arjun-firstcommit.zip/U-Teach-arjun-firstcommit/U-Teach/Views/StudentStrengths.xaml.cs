﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace UTeach.Views
{
    public partial class StudentStrengths : ContentPage
    {
        public StudentStrengths()
        {
            InitializeComponent();
        }

        async void Handle_Clicked_4(object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new StudentWeakness());

        }
    }
}
