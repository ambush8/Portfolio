﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace UTeach.Views
{
    public partial class TeacherSubject : ContentPage
    {
        public TeacherSubject()
        {
            InitializeComponent();
        }

        async void Handle_Clicked_5(object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new TeacherGrade());

        }
    }
}
